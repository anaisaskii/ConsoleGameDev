Snowconesolid Assets
� 2015, Samer Khatib
----------------------------------------------------
Support Email: samerkhb@gmail.com
Developer Website: snowconesolidwho.blogspot.com
----------------------------------------------------
Thank you for downloading
"Crazy Cats Toon Pack"
----------------------------------------------------
Info:
Package includes 9 colorful fully rigged, mecanim/animation ready low poly toon crazy cat character
models to use in your Unity project!
----------------------------------------------------
Package Content:
+9 Low Poly Toon crazy cat prefabs (2686 Tris each)
+Optimized compressed png Texture maps (1024x1024)
+8 different animation poses.
+Mecanim ready animator controller. Easily add your own animations to the controller
and watch your Crazy Cat buddy animate!

----------------------------------------------------
After Importing, Crazy Cat prefabs can be found in:

Snowconesolid Assets >>> Crazy Cats Toon Pack >>> Crazy Cats PREFABS

-----------------------------------------------------
For questions, comments or help please feel free to send me an email using the
support email provided above. Enjoy your package. Thank you. :)
-------------------------------------------------------------------------------------------
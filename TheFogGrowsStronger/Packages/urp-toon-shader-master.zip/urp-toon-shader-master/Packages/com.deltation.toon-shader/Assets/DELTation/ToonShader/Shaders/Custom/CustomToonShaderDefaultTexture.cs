﻿

namespace DELTation.ToonShader.Custom
{
	public enum CustomToonShaderDefaultTexture
	{
		Default,
		White,
		Black,
		Gray,
		Bump,
		Red,
	}
}
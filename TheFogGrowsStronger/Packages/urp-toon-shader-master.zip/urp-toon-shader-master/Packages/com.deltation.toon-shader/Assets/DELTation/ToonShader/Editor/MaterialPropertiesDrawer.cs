﻿namespace DELTation.ToonShader.Editor
{
	public delegate void MaterialPropertiesDrawer(in MaterialEditorContext context);
}
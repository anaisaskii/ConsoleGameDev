﻿namespace DELTation.ToonShader.Custom
{
	public enum CustomToonShaderPropertyType
	{
		Integer,
		Float,
		Texture2D,
		Texture2DArray,
		Texture3D,
		Cubemap,
		CubemapArray,
		Color,
		Vector,
		Range,
	}
}